#pragma once
#include <solution.h>
#include <iostream>
#include <problem.h>

using namespace std;

class Population {


  vector<tSolution> population;

  vector<tFitness> fitness;

  vector<vector<int>> grafo;

  const int GROUP_SIZE = 10;

  const float LOW_DENSITY = 0.15;
  const float MID_DENSITY = 0.3;
  const float HIGH_DENSITY = 0.6;

  

public:
  enum graphTypes{COMPLETE,CICLE,RANDOM_GROUPS,SYMETRICAL_GROUPS,RANDOM_LOW_DENSITY,RANDOM_MID_DENSITY,RANDOM_HIGH_DENSITY};

  Population(size_t size);

  void initializePop(size_t size);

  /*------------GETTERS------------*/

  size_t getPopulationSize() { return population.size(); }

  tFitness getFitness(int i){return fitness.at(i);}

  tSolution & getSolution(int i){return population.at(i);}

  vector<int> getNeighbourIndexes(int i);

  bool findSolution(tSolution & sol);

  /*------------OPERATORS------------*/

  void populate(Problem * problem);

  void generate_graph(graphTypes type);

  void mutateGraph(float percentageNodes, float intensity);

  void insert_sol(int i, tSolution & sol, tFitness fit);

  void insert_sol(int i, tSolution & sol, tFitness fit, vector<int> neightbours);

  void set_fitness(int i, tFitness fit);

  void print_pop();

  vector<int> getSortedIndex();


private:

  void generate_random_graph(float density);

};
