#include <RF.h>

RF::RF(Population pop, Problem * problem): 
    MH(), 
    MUTATE_PTOB(0.2),                  // Default value
    MUTATE_INTENSITY(0.75),            // Default value
    SELECT_PERCENTAGE(0.05),           // Default value
    POP_SIZE(100),                     // Default value
    MAX_ROUNDS(2),                     // Default value
    SELECT_SIZE(100*0.05),             // Calculated from defaults
    TOURNAMENT_RATIO(1.0),             // Default value
    pop(pop) {

    dist_PopSize = std::uniform_int_distribution<int>(0,POP_SIZE-1);
}

RF::RF(Population::graphTypes graphType, Problem * problem): 
    MH(), 
    MUTATE_PTOB(0.2),                  // Default value
    MUTATE_INTENSITY(0.75),            // Default value
    SELECT_PERCENTAGE(0.05),           // Default value
    POP_SIZE(100),                     // Default value
    MAX_ROUNDS(2),                     // Default value
    SELECT_SIZE(100*0.05),             // Calculated from defaults
    TOURNAMENT_RATIO(1.0),             // Default value
    pop(POP_SIZE) {
    pop.populate(problem);
    pop.generate_graph(graphType);
    evals = POP_SIZE;

    dist_PopSize = std::uniform_int_distribution<int>(0,POP_SIZE-1);
}

  
RF::RF(Population::graphTypes graphType, Problem * problem, float mp, double mi, float ps, int mr, double sp, float tr): 
MUTATE_PTOB(mp), MUTATE_INTENSITY(mi), POP_SIZE(ps), MAX_ROUNDS(mr), 
SELECT_PERCENTAGE(sp), TOURNAMENT_RATIO(tr), SELECT_SIZE(ps*sp), MH(), pop(ps) {
    pop.populate(problem);
    pop.generate_graph(graphType);
    evals = POP_SIZE;

    dist_PopSize = std::uniform_int_distribution<int>(0,POP_SIZE-1);
}

tFitness RF::getFitness(tSolution & sol, Problem * problem){
    ++evals;

    return problem->fitness(sol);
}

ResultMH RF::optimize(Problem * problem, int maxevals){
    return optimize(problem,maxevals,false);
}


ResultMH RF::optimize(Problem * problem, int maxevals, bool LocalSearch){
    
    vector<int> spreaders;
    std::map<tFitness, int> solsToLocalSearch;
int counter = 0;

    while(evals < maxevals){
        spreaders.clear();
        //vector<int> aux = pop.getSortedIndex();
        for(int i = 0; i < SELECT_SIZE; ++i){
            spreaders.push_back(select());
            //spreaders.push_back(aux.at(i));
        }
        solsToLocalSearch = propagate(spreaders,MAX_ROUNDS,problem);

        if(evals < maxevals)
            mutate(problem);

        // if(evals > 6*maxevals/10 && LocalSearch){
        //     localSearch(problem,pop.getSortedIndex().front(),4*maxevals/10);
        // }

        // cerr << counter++ << " ";
        // if(LocalSearch && counter%100 == 0){
        //     vector<int> best = pop.getSortedIndex();
        //     const int MAX_LOCAL_SEARCH = 3;
            
        //     for(int i = 0; i < MAX_LOCAL_SEARCH; ++i){
        //         if(evals < maxevals)
        //             localSearch(problem,best.at(i),1000);
        //     }
        // }

        // if(LocalSearch){
        //     if(evals > maxevals/2){
        //         int processedSols = 0;
        //         const int MAX_LOCAL_SEARCH = 3; // Only process top 3 solutions
                
        //         for(auto const& [fitness, sol] : solsToLocalSearch) {
        //             if(evals < maxevals && processedSols < MAX_LOCAL_SEARCH) {
        //                 localSearch(problem, sol, 100);
        //                 processedSols++;
        //             } else {
        //                 break;
        //             }
        //         }   
        //     } 
        // }
        
    }

    int BestSolIndex = pop.getSortedIndex().front();

    return ResultMH(pop.getSolution(BestSolIndex),pop.getFitness(BestSolIndex),evals);

}

/// @brief Select operator for the EA. 
int RF::select(){
    // int tournamentSize = ceil(POP_SIZE*TOURNAMENT_RATIO);
    // vector<int> index(tournamentSize);

    // for(int i = 0; i < tournamentSize; ++i){
    //     index.at(i) = Random::get(dist_PopSize);
    // }

    // sort(index.begin(),index.end(),[this](int &a, int &b){ return this->pop.getFitness(a) < this->pop.getFitness(b); });
    
    vector<int> index = pop.getSortedIndex();

    std::uniform_int_distribution<int> distSols(0,POP_SIZE/10);

    return index.at(Random::get(distSols));
}

std::map<tFitness, int> RF::propagate(vector<int> & cromosomes, int Nrounds, Problem * problem){
    vector<int> spreaders;
    vector<int> newSpreaders = cromosomes;
    vector<int> neighbours;

    std::map<tFitness, int> changed;

    for(int round = 0; round < Nrounds; ++round){
        spreaders = newSpreaders;
        newSpreaders.clear();

        for(int cromo = 0; cromo < spreaders.size(); ++cromo){
            changed[pop.getFitness(cromo)] = cromo;
            
            vector<int> orderedFitsIndex = pop.getSortedIndex();
            tFitness bestFit = pop.getFitness(orderedFitsIndex.front());
            tFitness worstFit = pop.getFitness(orderedFitsIndex.back());

            double percentageSpread = 1 - (this->pop.getFitness(spreaders.at(cromo))- bestFit)/(worstFit - bestFit);
            
            percentageSpread = percentageSpread/2;
            
            neighbours = pop.getNeighbourIndexes(spreaders.at(cromo));
            Random::shuffle(neighbours);
            int neighboursToRumor = neighbours.size()*percentageSpread;

            for(int neighbour = 0; neighbour < neighboursToRumor; neighbour++){
                cross(problem,spreaders.at(cromo),neighbours.at(neighbour));
                newSpreaders.push_back(neighbours.at(neighbour));
                changed[pop.getFitness(neighbours.at(neighbour))] = neighbours.at(neighbour);
            }
        }
    }

    return changed;
}
    
void RF::cross(Problem * problem, int spreader, int listener){
    double d = 0.20;
    double length = 1 + 2*d;
    vector<int> orderedFitsIndex = pop.getSortedIndex();
    tFitness bestFit = pop.getFitness(orderedFitsIndex.front());
    tFitness worstFit = pop.getFitness(orderedFitsIndex.back());
    double fitnessRatio = (pop.getFitness(listener) - pop.getFitness(spreader))/(worstFit - bestFit);

    std::uniform_real_distribution<double> ratio(-d* (1 + fitnessRatio), 1 + d * (1 + fitnessRatio));
    
    for(int i = 0; i < problem->getSolutionSize(); ++ i){
        double randomRatio = Random::get(ratio);
        //Fijar algunas aveces??
        pop.getSolution(listener).at(i) = pop.getSolution(spreader).at(i)*randomRatio + pop.getSolution(listener).at(i)*(1-randomRatio);

            
        if(pop.getSolution(listener).at(i) > 100)
            pop.getSolution(listener).at(i) = 100;
        else if( pop.getSolution(listener).at(i) < -100){
            pop.getSolution(listener).at(i) = -100;
        }        
    }

    pop.set_fitness(listener,getFitness(pop.getSolution(listener),problem));
}
    
void RF::mutate(Problem * problem){
    int solsToMutate = MUTATE_PTOB*pop.getPopulationSize();

    //Se puede guardar un vecotr con los numeros de las soluciones shufleado

    vector<int> sols(pop.getPopulationSize());

    for(int i = 0; i < pop.getPopulationSize(); ++i){
        sols.at(i) = i;
    }

    Random::shuffle(sols);
    std::uniform_real_distribution<double> randDist(-1,1);

    for(int i = 0; i < solsToMutate; ++i){
        for(int j = 0; j < problem->getSolutionSize(); ++j){
            pop.getSolution(sols.at(i)).at(j) += Random::get(randDist)*MUTATE_INTENSITY;
            
            if(pop.getSolution(sols.at(i)).at(j) > 100)
                pop.getSolution(sols.at(i)).at(j) = 100;
            else if( pop.getSolution(sols.at(i)).at(j) < -100){
                pop.getSolution(sols.at(i)).at(j) = -100;
            }
        }
        pop.set_fitness(i,getFitness(pop.getSolution(i),problem));
    }

    
}

void RF::localSearch(Problem * problem, int cromosome, int evals){
    std::uniform_real_distribution<double> randDist(-1,1);

    tFitness bestFit = pop.getFitness(cromosome);
    tSolution workingSol = this->pop.getSolution(cromosome);
    tSolution neighbourSol;
    for(int i = 0; i < evals; ++i){

        neighbourSol = workingSol;

        for(int j = 0; j < problem->getSolutionSize(); ++j){
            neighbourSol.at(j) += Random::get(randDist)*MUTATE_INTENSITY;

            if(neighbourSol.at(j) > 100)
                neighbourSol.at(j) = 100;
            else if( neighbourSol.at(j) < -100){
                neighbourSol.at(j) = -100;
            }
        }

        tFitness fit = this->getFitness(neighbourSol,problem);

        if(fit < bestFit){
            workingSol = neighbourSol;
            bestFit = fit;
        }
    }

    pop.insert_sol(cromosome,workingSol,bestFit);
}